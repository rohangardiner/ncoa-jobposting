# NCOA Jobposting
Scrape job ads and show a customisable list to users

## Changelog
~Current Version:1.0.0~

### 1.0.0
* Plugin created