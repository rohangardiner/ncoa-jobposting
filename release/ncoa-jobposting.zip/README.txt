=== NCOA Jobposting ===
Contributors: rohangardiner
Tags: career, post
Requires at least: 3.0.1
Tested up to: 6.8.1
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Scrape job ads and show a customisable list to users

~Current Version:1.0.1~

== Changelog ==

= 1.0.0 =
* Plugin created